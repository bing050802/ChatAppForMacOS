Giffy
=====

It takes a folder with exported images (maily from Final Cut Pro) and transform it into an animated gif
