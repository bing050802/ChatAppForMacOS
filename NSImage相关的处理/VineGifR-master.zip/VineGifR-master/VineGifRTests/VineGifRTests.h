//
//  VineGifRTests.h
//  VineGifRTests
//
//  Created by Esten Hurtle on 1/27/13.
//  Copyright (c) 2013 Esten Hurtle. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface VineGifRTests : SenTestCase

@end
