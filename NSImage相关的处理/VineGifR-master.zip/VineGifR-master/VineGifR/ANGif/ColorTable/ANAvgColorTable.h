//
//  ANGifBasicColorTable.h
//  GifPro
//
//  Created by Alex Nichol on 11/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ANColorTable.h"

@interface ANAvgColorTable : ANColorTable {
	
}

@end
